package org.ssmm2.example.persistence.mapper;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

public interface BaseMapper {
	int insert(Map<String,String> entity) throws SQLException;
	int insertAll(List<Map<String,String>> entitys) throws SQLException;
	int delete(Map<String,String>...entity) throws SQLException;
	int delete(String...id) throws SQLException;
	int update(Map<String,String>...entity) throws SQLException;
	List<Map<String,Object>> select(String...id) throws SQLException;
	List<Map<String,Object>> find(Map<String,String>...entity) throws SQLException;
	long count(Map<String,Object>... entity) throws SQLException;
}
