package org.ssmm2.example.service.impl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.ssmm2.example.persistence.mapper.UserMapper;
import org.ssmm2.example.service.UserService;
import java.util.Map;

@Service()
public class UserServiceImpl implements UserService {
	@Autowired
	private UserMapper userMapper=null;

	public int delete(Map<String, String> user) throws Exception {
		return  userMapper.delete(user);
	}

	public int add(Map<String, String> user) throws Exception {
		return   userMapper.insert(user);
	}




}
